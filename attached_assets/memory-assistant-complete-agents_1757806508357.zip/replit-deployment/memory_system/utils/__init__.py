"""
Utilities package for Memory System
"""

from .logger import setup_logging

__all__ = ["setup_logging"]


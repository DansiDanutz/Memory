"""
Configuration package for Memory System
"""

from .settings import Settings

__all__ = ["Settings"]


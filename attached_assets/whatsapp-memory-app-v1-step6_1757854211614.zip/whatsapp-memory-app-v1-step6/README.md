# WhatsApp Memory App — Phase‑1 with Step 6

Follow STEP-1.md … STEP-6.md to deploy.

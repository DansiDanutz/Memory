import os, time
from typing import Optional
try:
    import redis  # type: ignore
except Exception:
    redis = None

REDIS_URL = os.getenv("REDIS_URL")

class _MemoryStore:
    def __init__(self, ttl_seconds: int = 600):
        self.ttl = ttl_seconds
        self._map = {}
    def mark_verified(self, phone: str):
        self._map[phone] = time.time() + self.ttl
    def is_verified(self, phone: str) -> bool:
        now = time.time()
        exp = self._map.get(phone)
        if not exp: return False
        if exp < now:
            self._map.pop(phone, None); return False
        return True
    def clear(self, phone: str):
        self._map.pop(phone, None)

class _RedisStore:
    def __init__(self, url: str, ttl_seconds: int = 600):
        self.ttl = ttl_seconds
        self.r = redis.Redis.from_url(url, decode_responses=True)
        self.prefix = "memapp:verified:"
    def mark_verified(self, phone: str):
        self.r.setex(self.prefix+phone, self.ttl, "1")
    def is_verified(self, phone: str) -> bool:
        return self.r.get(self.prefix+phone) == "1"
    def clear(self, phone: str):
        self.r.delete(self.prefix+phone)

def build_session_store(ttl_seconds: int = 600):
    if REDIS_URL and redis is not None:
        try:
            store = _RedisStore(REDIS_URL, ttl_seconds=ttl_seconds)
            store.r.ping()
            return store
        except Exception:
            pass
    return _MemoryStore(ttl_seconds=ttl_seconds)

store = build_session_store()
def mark_verified(phone: str): store.mark_verified(phone)
def is_verified(phone: str) -> bool: return store.is_verified(phone)
def clear_verified(phone: str): store.clear(phone)

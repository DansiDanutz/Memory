from cryptography.fernet import Fernet
def build_fernet(master_key_b64: str) -> Fernet:
    return Fernet(master_key_b64.encode("utf-8"))
def encrypt_text(master_key_b64: str, plaintext: str) -> str:
    return build_fernet(master_key_b64).encrypt(plaintext.encode("utf-8")).decode("utf-8")
def decrypt_text(master_key_b64: str, token: str) -> str:
    return build_fernet(master_key_b64).decrypt(token.encode("utf-8")).decode("utf-8")

import hashlib, yaml, os
def _meta_path(base_dir: str, phone: str) -> str:
    return os.path.join(base_dir, "contacts", phone, "meta.yaml")
def set_passphrase(base_dir: str, phone: str, passphrase: str):
    meta_path = _meta_path(base_dir, phone)
    meta = {}
    if os.path.exists(meta_path):
        meta = yaml.safe_load(open(meta_path, "r", encoding="utf-8")) or {}
    h = hashlib.sha256(passphrase.strip().lower().encode("utf-8")).hexdigest()
    meta.setdefault("voice", {})["passphrase_hash"] = h
    os.makedirs(os.path.dirname(meta_path), exist_ok=True)
    with open(meta_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(meta, f, sort_keys=True)
def verify_passphrase(base_dir: str, phone: str, passphrase: str) -> bool:
    meta_path = _meta_path(base_dir, phone)
    if not os.path.exists(meta_path): return False
    meta = yaml.safe_load(open(meta_path, "r", encoding="utf-8")) or {}
    expected = meta.get("voice", {}).get("passphrase_hash")
    if not expected: return False
    h = hashlib.sha256(passphrase.strip().lower().encode("utf-8")).hexdigest()
    return h == expected

import os, re
from typing import List, Dict, Tuple, Optional
from ..config import settings
from ..security.encryption import decrypt_text
from ..metrics import search_queries_total

DEFAULT_CATEGORIES = ["general","chronological","confidential","secret","ultra-secret"]
ENC_PREFIX = "ENC::"

def _read_md(path: str) -> str:
    try: return open(path, "r", encoding="utf-8").read()
    except Exception: return ""

def find_segments(md: str) -> List[Tuple[str,str]]:
    segments=[]; current=[]; head=""
    for line in md.splitlines():
        if line.startswith("## "):
            if head: segments.append((head, "\n".join(current)))
            head=line[3:]; current=[]
        else: current.append(line)
    if head: segments.append((head, "\n".join(current)))
    return segments

def _extract_classification(seg: str) -> str:
    m = re.search(r"^- Classification:\s*(.+)$", seg, flags=re.M)
    return (m.group(1).strip() if m else "general").lower()

def _extract_message(seg: str) -> Tuple[str, bool]:
    enc=False; block=[]; in_block=False
    for line in seg.splitlines():
        if line.startswith("- Message (encrypted):"):
            enc=True; in_block=True; continue
        if line.startswith("- Message:"):
            enc=False; in_block=True; continue
        if in_block:
            if line.startswith("- "): break
            if line.startswith("    "): block.append(line[4:])
            elif line.strip()=="": block.append("")
            else: break
    return "\n".join(block).strip(), enc

def _decrypt_if_needed(text: str, enc: bool) -> str:
    if not enc: return text
    if not text.startswith(ENC_PREFIX): return ""
    token = text[len(ENC_PREFIX):].strip()
    key = settings.encryption_master_key
    if not key: return ""
    try: return decrypt_text(key, token)
    except Exception: return ""

def search_contact_memories(base_dir: str, phone: str, query: str, max_hits: int=6, allowed_categories: Optional[List[str]]=None) -> List[Dict]:
    contact_dir = os.path.join(base_dir, "contacts", phone, "memories")
    hits: List[Dict]=[]
    if not os.path.isdir(contact_dir): return hits

    allowed_secret = "yes" if ("secret" in (allowed_categories or []) or "ultra-secret" in (allowed_categories or [])) else "no"
    try: search_queries_total.labels(allowed_secret=allowed_secret).inc()
    except Exception: pass

    q = query.strip().lower()
    cats = allowed_categories if allowed_categories else DEFAULT_CATEGORIES
    for cat in cats:
        path = os.path.join(contact_dir, f"{cat}.md")
        md = _read_md(path)
        for head, seg in find_segments(md):
            msg_raw, enc = _extract_message(seg)
            msg = _decrypt_if_needed(msg_raw, enc)
            if enc and not msg:
                continue
            text=(head+"\n"+msg).lower()
            score=sum([1 for tok in q.split() if tok in text])
            if score>0:
                excerpt = (msg[:240]+"…") if len(msg)>240 else msg
                hits.append({"category":cat,"heading":head,"excerpt":excerpt,"score":score,"path":path})
    hits.sort(key=lambda x:x["score"], reverse=True)
    return hits[:max_hits]

import os, yaml, datetime, re
from typing import Dict, Any, Optional, Tuple, List
from .classifier import CATEGORY_GENERAL, CATEGORY_CHRONO, CATEGORY_CONF, CATEGORY_SECRET, CATEGORY_ULTRA, classify
from ..security.encryption import encrypt_text
from ..config import settings
from ..metrics import messages_total

def normalize_msisdn(msisdn: str) -> str:
    msisdn = re.sub(r"[^0-9+]", "", msisdn.strip())
    if not msisdn.startswith("+") and msisdn and msisdn[0].isdigit():
        return "+" + msisdn
    return msisdn

def ensure_contact_dirs(base_dir: str, phone: str) -> str:
    phone = normalize_msisdn(phone)
    contact_dir = os.path.join(base_dir, "contacts", phone)
    mem_dir = os.path.join(contact_dir, "memories")
    os.makedirs(mem_dir, exist_ok=True)
    for cat in [CATEGORY_GENERAL, CATEGORY_CHRONO, CATEGORY_CONF, CATEGORY_SECRET, CATEGORY_ULTRA]:
        path = os.path.join(mem_dir, f"{cat}.md")
        if not os.path.exists(path):
            with open(path, "w", encoding="utf-8") as f:
                f.write(f"---\ncontact: {phone}\ncategory: {cat}\ncreated: {datetime.date.today().isoformat()}\n---\n\n")
    meta_path = os.path.join(contact_dir, "meta.yaml")
    if not os.path.exists(meta_path):
        os.makedirs(os.path.dirname(meta_path), exist_ok=True)
        with open(meta_path, "w", encoding="utf-8") as f:
            yaml.safe_dump({"contact": phone, "display_name": None, "voice": {}, "created": datetime.datetime.utcnow().isoformat()+"Z"}, f)
    return contact_dir

def append_markdown_entry(md_path: str, entry_md: str):
    with open(md_path, "a", encoding="utf-8") as f:
        f.write(entry_md)

def build_entry(ts_utc: datetime.datetime, direction: str, body: str, meta: Dict[str, Any], classification: str, encrypted: bool, reasons: List[str]) -> str:
    ts = ts_utc.replace(microsecond=0).isoformat()+"Z"
    safe_body = body.replace("\n", "\n    ")
    label = "Message (encrypted)" if encrypted else "Message"
    parts = [f"## {ts} — {direction}", "", f"- {label}:", f"    {safe_body}", f"- Classification: {classification}", f"- Reasons: {', '.join(reasons)}"]
    if meta:
        parts.append(f"- Meta:\n    " + "\n    ".join([f"{k}: {v}" for k,v in meta.items()]))
    parts.append("\n")
    return "\n".join(parts)

def save_incoming_text(base_dir: str, phone: str, text: str, meta: Optional[Dict[str, Any]]=None) -> Tuple[str, Dict[str, Any]]:
    contact_dir = ensure_contact_dirs(base_dir, phone)
    mem_dir = os.path.join(contact_dir, "memories")
    classification, reasons = classify(text)

    # Encrypt body for secret tiers if key present
    encrypted = False
    body_to_store = text
    if classification in (CATEGORY_SECRET, CATEGORY_ULTRA) and settings.encryption_master_key:
        try:
            cipher = encrypt_text(settings.encryption_master_key, text)
            body_to_store = f"ENC::{cipher}"
            encrypted = True
        except Exception:
            body_to_store = text
            encrypted = False

    entry = build_entry(datetime.datetime.utcnow(), "Incoming", body_to_store, meta or {}, classification, encrypted, reasons)

    append_markdown_entry(os.path.join(mem_dir, f"{CATEGORY_CHRONO}.md"), entry)
    append_markdown_entry(os.path.join(mem_dir, f"{classification}.md"), entry)

    try:
        messages_total.labels(category=classification).inc()
    except Exception:
        pass

    return classification, {"contact_dir": contact_dir, "classification": classification}

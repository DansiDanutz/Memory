from prometheus_client import Counter
messages_total = Counter("memory_messages_total", "Total messages saved", ["category"])
search_queries_total = Counter("memory_search_queries_total", "Total search queries", ["allowed_secret"])

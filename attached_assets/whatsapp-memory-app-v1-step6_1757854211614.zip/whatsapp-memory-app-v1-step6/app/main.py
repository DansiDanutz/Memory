from fastapi import FastAPI, Query
from fastapi.responses import Response, PlainTextResponse
from .logging_conf import configure_logging
from .config import settings
from .whatsapp import router as wa_router
from .memory.search import search_contact_memories
from .voice.guard import set_passphrase, verify_passphrase
from .security.session_store import mark_verified, is_verified
from .metrics import messages_total, search_queries_total
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
import os

configure_logging()

app = FastAPI(title="Memory WhatsApp App", version="1.1.0")
app.include_router(wa_router)

@app.get("/")
def root():
    return {"status":"ok","public_url": settings.app_public_url}

@app.get("/healthz")
def health():
    return {"ok": True}

@app.get("/metrics")
def metrics():
    data = generate_latest()
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)

@app.get("/admin/status")
def admin_status():
    base = settings.data_dir
    stats = {}
    contacts_dir = os.path.join(base, "contacts")
    if os.path.isdir(contacts_dir):
        for contact in os.listdir(contacts_dir):
            mem_dir = os.path.join(contacts_dir, contact, "memories")
            if not os.path.isdir(mem_dir): continue
            cat_stats = {}
            for cat in ["general","chronological","confidential","secret","ultra-secret"]:
                path = os.path.join(mem_dir, f"{cat}.md")
                try:
                    txt = open(path, "r", encoding="utf-8").read()
                    count = len([1 for line in txt.splitlines() if line.startswith("## ")])
                except Exception:
                    count = 0
                cat_stats[cat] = count
            stats[contact] = cat_stats
    return {"contacts": len(stats), "by_contact": stats}

@app.post("/voice/enroll-passphrase")
def enroll_passphrase(phone: str, passphrase: str):
    set_passphrase(settings.data_dir, phone, passphrase)
    return {"status": "enrolled"}

@app.post("/voice/verify")
def verify(phone: str, passphrase: str):
    ok = verify_passphrase(settings.data_dir, phone, passphrase)
    if ok:
        mark_verified(phone)
    return {"verified": ok}

@app.post("/memory/search")
def search(phone: str, q: str):
    allowed = ["general","chronological","confidential"]
    if is_verified(phone):
        allowed += ["secret","ultra-secret"]
    hits = search_contact_memories(settings.data_dir, phone, q, allowed_categories=allowed)
    return {"results": hits}

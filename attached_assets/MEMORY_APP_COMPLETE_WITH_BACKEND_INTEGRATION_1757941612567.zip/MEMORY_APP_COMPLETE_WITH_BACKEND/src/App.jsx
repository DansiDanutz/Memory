import React from 'react'
import MemoryApp from './components/MemoryApp'
import './App.css'

function App() {
  return <MemoryApp />
}

export default App

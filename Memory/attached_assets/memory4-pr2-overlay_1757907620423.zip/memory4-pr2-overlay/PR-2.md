# PR‑2 — Tenancy, RBAC & Audit (Business Mode)

This overlay enables **business features** on top of Phase‑1:
- **Tenancy** with departments and roles
- **RBAC** to control cross‑scope search
- **Audit log** for department/tenant searches

## What’s included
- `app/tenancy/model.py` — YAML loader for `data/tenants/tenants.yaml`
- `app/tenancy/rbac.py` — role matrix and helpers
- `app/memory/search_multi.py` — aggregate search across phones
- `app/audit.py` — JSONL writer to `data/audit/audit.log`
- `app/webhook.py` — updated with:
  - `whoami`
  - `search dept: <query>` (roles: owner/admin/manager/auditor)
  - `search tenant: <query>` (roles: owner/admin/auditor)
  - **No SECRET/ULTRA_SECRET** in cross‑scope results
  - ULTRA‑SECRET remains **self‑scope only**
- Admin endpoints (patch snippet for `app/main.py`):
  - `POST /admin/tenants/reload`
  - `GET /admin/tenants`
  - `GET /admin/whoami?phone=+1555...`
- Sample `data/tenants/tenants.yaml`

## Apply
1. Unzip this overlay into your repo root and overwrite files.
2. Ensure `data/tenants/tenants.yaml` reflects your org (edit phones/roles).
3. Restart the app. In WhatsApp:
   - `whoami`
   - `search dept: <query>` (if authorized)
   - `search tenant: <query>` (if authorized)

## Notes
- Cross‑scope searches are limited to **GENERAL/CHRONOLOGICAL/CONFIDENTIAL**.
- `SECRET` and `ULTRA_SECRET` remain **private**; ULTRA_SECRET is **self‑only** by code.
- All cross‑scope searches write to `data/audit/audit.log`.
- You can reload the YAML live via `POST /admin/tenants/reload`.

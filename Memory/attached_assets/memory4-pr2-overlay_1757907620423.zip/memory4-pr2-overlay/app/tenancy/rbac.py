from typing import Literal, Tuple, Optional, Dict
from .model import TENANCY

Role = Literal["owner","admin","manager","member","auditor"]
Scope = Literal["self","department","tenant"]

# allowed roles per scope
DEPT_ROLES = {"owner","admin","manager","auditor"}
TENANT_ROLES = {"owner","admin","auditor"}

def whoami(phone: str) -> Optional[Dict]:
    return TENANCY.get_user(phone)

def can_search(phone: str, scope: Scope) -> Tuple[bool, str]:
    if scope == "self":
        return True, "self"
    u = TENANCY.get_user(phone)
    if not u:
        return False, "no-tenant"
    role = u.get("role","member")
    if scope == "department":
        return (role in DEPT_ROLES, role)
    if scope == "tenant":
        return (role in TENANT_ROLES, role)
    return False, "invalid-scope"

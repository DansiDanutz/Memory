import os, json, time
AUDIT_DIR = os.getenv("AUDIT_DIR", "data/audit")
os.makedirs(AUDIT_DIR, exist_ok=True)
AUDIT_FILE = os.path.join(AUDIT_DIR, "audit.log")

def audit_event(event_type: str, **data):
    rec = {"ts_ms": int(time.time()*1000), "event": event_type}
    rec.update(data)
    try:
        with open(AUDIT_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")
    except Exception:
        pass

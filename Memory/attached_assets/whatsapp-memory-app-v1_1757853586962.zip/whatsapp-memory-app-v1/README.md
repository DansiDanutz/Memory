# WhatsApp Memory App — Phase‑1

Follow STEP-1.md … STEP-5.md to deploy.

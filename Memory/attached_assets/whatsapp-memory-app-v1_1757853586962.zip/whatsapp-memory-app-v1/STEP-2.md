# STEP 2 — Search in Markdown (from chat)

**Goal:** Add a simple **keyword search** over each contact’s Markdown files and expose it to users via WhatsApp by typing `search: <query>`.

---

## 1) What’s in this step

- `app/memory/search.py` — scans the 5 category files for a contact, slices entries by headings, ranks simple keyword matches, returns top hits.
- `app/whatsapp.py` — detects `search:` in incoming text, runs search, and responds with top 3 timestamps + categories.

The search respects **allowed categories** (we’ll wire voice‑based security in Step 3; for now we allow `general`, `chronological`, `confidential`).

---

## 2) Try it

Type in your WhatsApp chat with the bot:

```
search: flight
search: seed phrase
search: passport
```

You’ll receive a short list like:

```
Top matches:
- [confidential] 2025-09-10T18:02:01Z — Incoming
- [general] 2025-09-07T09:33:05Z — Incoming
```

---

## 3) Implementation highlights

- Function signature: `search_contact_memories(base_dir, phone, q, max_hits=6, allowed_categories=None)`
- We’ll add voice‑gated categories in Step 3 and include `secret` / `ultra-secret` only after verification.


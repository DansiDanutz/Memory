# STEP 5 — Deploy, Monitor, Operate

**Goal:** Run this safely for WhatsApp‑only production (Phase‑1).

---

## 1) Deploy

### Replit
- Import repo, add Secrets, click **Run**. Replit gives you an HTTPS URL.  
- Paste URL + `META_VERIFY_TOKEN` into the WhatsApp webhook configuration and **Verify**.

### Docker
```bash
docker build -t memory-wa .
docker run -e META_ACCESS_TOKEN=... -e WA_PHONE_NUMBER_ID=...            -e META_VERIFY_TOKEN=... -e APP_PUBLIC_URL=https://your-host            -e AZURE_SPEECH_KEY=... -e AZURE_SPEECH_REGION=...            -p 8000:8000 memory-wa
```

---

## 2) Observability

- JSON logs to stdout (Replit console or log shipper).  
- Optional: add `/metrics` with Prometheus later.

---

## 3) Backups & Data Handling

- Nightly zip of `data/contacts/` shipped to off‑box storage.  
- Test restore quarterly.  
- Never commit `data/` to git. Protect tokens and avoid storing secrets in plaintext (future: encrypt secret/ultra‑secret MD with key rotation).

---

## 4) Acceptance checklist

- **Text ➜ Stored**: sending “My passport ABC123” lands in `confidential.md`.  
- **Voice ➜ Verify**: “verify: <phrase>” unlocks secret tiers for 10 minutes.  
- **Voice ➜ Query**: ask by voice “hotel details for Rome” → text + audio answer with top matches.  
- **Denied access**: asking for “seed phrase” without verification returns a prompt to verify, not the content.


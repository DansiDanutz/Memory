from fastapi import FastAPI, Query
from .logging_conf import configure_logging
from .config import settings
from .whatsapp import router as wa_router
from .memory.search import search_contact_memories
from .voice.guard import set_passphrase, verify_passphrase
from .security.session import mark_verified, is_verified

configure_logging()

app = FastAPI(title="Memory WhatsApp App", version="1.0.0")
app.include_router(wa_router)

@app.get("/")
def root():
    return {"status":"ok","public_url": settings.app_public_url}

@app.get("/healthz")
def health():
    return {"ok": True}

# Optional programmatic endpoints (useful for tests / operator tools)
@app.post("/voice/enroll-passphrase")
def enroll_passphrase(phone: str, passphrase: str):
    set_passphrase(settings.data_dir, phone, passphrase)
    return {"status": "enrolled"}

@app.post("/voice/verify")
def verify(phone: str, passphrase: str):
    ok = verify_passphrase(settings.data_dir, phone, passphrase)
    if ok:
        mark_verified(phone)
    return {"verified": ok}

@app.post("/memory/search")
def search(phone: str, q: str):
    allowed = ["general","chronological","confidential"]
    if is_verified(phone):
        allowed += ["secret","ultra-secret"]
    hits = search_contact_memories(settings.data_dir, phone, q, allowed_categories=allowed)
    return {"results": hits}

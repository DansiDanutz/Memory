import requests, json, uuid, os
from fastapi import APIRouter, Request, Response
from fastapi.responses import PlainTextResponse
from .config import settings
from .memory.storage import save_incoming_text
from .memory.search import search_contact_memories
from .voice.guard import set_passphrase, verify_passphrase
from .security.session import is_verified, mark_verified
from .voice.azure_voice import transcribe_wav, synthesize_to_file
from .voice.whatsapp_media import download_media, ogg_opus_to_wav, upload_media, send_audio

router = APIRouter(prefix="/webhook/whatsapp")
GRAPH_BASE = "https://graph.facebook.com/v20.0"

def _send_message(to: str, text: str) -> requests.Response:
    url = f"{GRAPH_BASE}/{settings.wa_phone_number_id}/messages"
    headers = {"Authorization": f"Bearer {settings.meta_access_token}"}
    payload = {"messaging_product":"whatsapp","to":to,"type":"text","text":{"preview_url":False,"body":text[:4096]}}
    return requests.post(url, headers=headers, json=payload, timeout=15)

def _allowed_categories(phone: str):
    allowed = ["general","chronological","confidential"]
    if is_verified(phone):
        allowed.extend(["secret","ultra-secret"])
    return allowed

@router.get("/", response_class=PlainTextResponse)
async def verify(request: Request):
    args = dict(request.query_params)
    if args.get("hub.mode") == "subscribe" and args.get("hub.verify_token") == settings.verify_token:
        return PlainTextResponse(args.get("hub.challenge",""), status_code=200)
    return PlainTextResponse("verification failed", status_code=403)

@router.post("/")
async def inbound(request: Request):
    body = await request.json()
    try:
        for entry in body.get("entry", []):
            for ch in entry.get("changes", []):
                value = ch.get("value", {})
                messages = value.get("messages", [])
                contacts = value.get("contacts", [])
                contact_name = contacts[0].get("profile", {}).get("name") if contacts else None
                for msg in messages:
                    mtype = msg.get("type"); from_num = msg.get("from")
                    if not from_num:
                        continue

                    # TEXT COMMANDS
                    if mtype == "text":
                        text = msg.get("text", {}).get("body", "").strip()
                        lower = text.lower()

                        # Enroll passphrase via chat: "enroll: my secret phrase"
                        if lower.startswith("enroll:") or lower.startswith("set passphrase:"):
                            phrase = text.split(":",1)[1].strip()
                            if not phrase:
                                _send_message(from_num, "Please provide a passphrase, e.g., 'enroll: my secret phrase'")
                            else:
                                set_passphrase(settings.data_dir, from_num, phrase)
                                _send_message(from_num, "Passphrase enrolled. Say or type: 'verify: <your passphrase>' to unlock secret tiers for 10 minutes.")
                            continue

                        # Verify passphrase via chat: "verify: <phrase>"
                        if lower.startswith("verify:") or lower.startswith("passphrase:"):
                            phrase = text.split(":",1)[1].strip()
                            if verify_passphrase(settings.data_dir, from_num, phrase):
                                mark_verified(from_num)
                                _send_message(from_num, "Verified. Secret tiers unlocked for 10 minutes.")
                            else:
                                _send_message(from_num, "Verification failed. Try again or re-enroll.")
                            continue

                        # Search: "search: <query>"
                        if lower.startswith("search:"):
                            q = text.split(":",1)[1].strip()
                            hits = search_contact_memories(settings.data_dir, from_num, q, allowed_categories=_allowed_categories(from_num))
                            if not hits:
                                _send_message(from_num, f"No matches for: {q}")
                            else:
                                lines = [f"- [{h['category']}] {h['heading']}" for h in hits[:3]]
                                _send_message(from_num, "Top matches:\n" + "\n".join(lines))
                            continue

                        # Otherwise store the message
                        meta = {"wa_msg_id": msg.get("id"), "name": contact_name}
                        cls, _ = save_incoming_text(settings.data_dir, from_num, text, meta)
                        _send_message(from_num, f"Saved to {cls}. You can 'search: <query>' or send a voice note.")

                    # AUDIO (voice note)
                    elif mtype == "audio":
                        media_id = msg.get("audio",{}).get("id")
                        if not media_id:
                            _send_message(from_num, "No audio id found.")
                            continue
                        # Download and transcribe
                        ogg = download_media(media_id)
                        wav = ogg_opus_to_wav(ogg)
                        transcript = transcribe_wav(wav, settings.azure_speech_key, settings.azure_speech_region) if settings.azure_speech_key else ""
                        if not transcript:
                            _send_message(from_num, "I couldn't understand the audio.")
                            continue
                        # Passphrase via voice: "passphrase is ..." or "verify: ..."
                        ltr = transcript.lower().strip()
                        if ltr.startswith("verify:") or ltr.startswith("passphrase:") or ltr.startswith("my passphrase is"):
                            phrase = transcript.split(":",1)[1].strip() if ":" in transcript else ltr.replace("my passphrase is","").strip()
                            if verify_passphrase(settings.data_dir, from_num, phrase):
                                mark_verified(from_num)
                                _send_message(from_num, "Verified by voice. Secret tiers unlocked for 10 minutes.")
                            else:
                                _send_message(from_num, "Voice verification failed. Please try again.")
                            continue

                        # Treat as a voice query
                        hits = search_contact_memories(settings.data_dir, from_num, transcript, allowed_categories=_allowed_categories(from_num))
                        if not hits:
                            answer = f"No matches for: {transcript}"
                        else:
                            top = hits[:3]
                            lines = [f"- [{h['category']}] {h['heading']}" for h in top]
                            answer = f"Query: {transcript}\nTop matches:\n" + "\n".join(lines)

                        # Synthesize and reply
                        audio_mp3 = f"/tmp/{uuid.uuid4().hex}.mp3"
                        sent_voice = False
                        if settings.azure_speech_key and synthesize_to_file(answer, audio_mp3, settings.azure_speech_key, settings.azure_speech_region):
                            mid = upload_media(audio_mp3)
                            send_audio(from_num, mid)
                            sent_voice = True
                        _send_message(from_num, answer + ("\n(Sent voice reply)" if sent_voice else ""))

                    # Other media types
                    else:
                        _send_message(from_num, "Please send text or a voice note. Media storage is disabled in this version.")
        return {"status":"ok"}
    except Exception:
        # Avoid webhook retries from Meta by returning 200 even on errors.
        return Response(status_code=200)

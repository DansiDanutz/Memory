import time
from typing import Dict

# super-simple in-memory verification cache; replace with Redis for multi-instance
_VERIFIED: Dict[str, float] = {}
TTL_SECONDS = 10*60  # 10 minutes

def mark_verified(phone: str):
    _VERIFIED[phone] = time.time() + TTL_SECONDS

def is_verified(phone: str) -> bool:
    now = time.time()
    exp = _VERIFIED.get(phone)
    if not exp:
        return False
    if exp < now:
        _VERIFIED.pop(phone, None)
        return False
    return True

def clear_verified(phone: str):
    _VERIFIED.pop(phone, None)

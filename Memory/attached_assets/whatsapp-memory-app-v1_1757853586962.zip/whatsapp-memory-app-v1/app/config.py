from pydantic import BaseModel
import os

class Settings(BaseModel):
    # Meta / WhatsApp Cloud API
    meta_access_token: str = os.getenv("META_ACCESS_TOKEN","")
    wa_phone_number_id: str = os.getenv("WA_PHONE_NUMBER_ID","")
    verify_token: str = os.getenv("META_VERIFY_TOKEN","change-me")
    app_public_url: str = os.getenv("APP_PUBLIC_URL","")
    data_dir: str = os.getenv("DATA_DIR","./data")
    timezone: str = os.getenv("TZ","UTC")

    # Azure Speech
    azure_speech_key: str = os.getenv("AZURE_SPEECH_KEY","")
    azure_speech_region: str = os.getenv("AZURE_SPEECH_REGION","")

    # Feature flags
    voice_enabled: bool = os.getenv("VOICE_ENABLED","true").lower() == "true"

    # Crypto (future encryption of MD sections)
    encryption_master_key: str = os.getenv("ENCRYPTION_MASTER_KEY","")

settings = Settings()

import os
from typing import List, Dict, Tuple, Optional

DEFAULT_CATEGORIES = ["general","chronological","confidential","secret","ultra-secret"]

def _read_md(path: str) -> str:
    try:
        return open(path, "r", encoding="utf-8").read()
    except Exception:
        return ""

def find_segments(md: str) -> List[Tuple[str,str]]:
    segments = []; current = []; head = ""
    for line in md.splitlines():
        if line.startswith("## "):
            if head:
                segments.append((head, "\n".join(current)))
            head = line[3:]
            current = []
        else:
            current.append(line)
    if head:
        segments.append((head, "\n".join(current)))
    return segments

def search_contact_memories(base_dir: str, phone: str, query: str, max_hits: int=6, allowed_categories: Optional[List[str]]=None) -> List[Dict]:
    contact_dir = os.path.join(base_dir, "contacts", phone, "memories")
    hits: List[Dict] = []
    if not os.path.isdir(contact_dir):
        return hits
    q = query.strip().lower()
    cats = allowed_categories if allowed_categories else DEFAULT_CATEGORIES
    for cat in cats:
        path = os.path.join(contact_dir, f"{cat}.md")
        md = _read_md(path)
        for head, seg in find_segments(md):
            text = (head + "\n" + seg).lower()
            score = sum(1 for tok in q.split() if tok in text)
            if score > 0:
                hits.append({"category": cat, "heading": head, "excerpt": seg[:280], "score": score, "path": path})
    hits.sort(key=lambda x: x["score"], reverse=True)
    return hits[:max_hits]

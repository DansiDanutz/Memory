import re
from typing import Tuple, List, Dict

CATEGORY_GENERAL = "general"
CATEGORY_CHRONO  = "chronological"
CATEGORY_CONF    = "confidential"
CATEGORY_SECRET  = "secret"
CATEGORY_ULTRA   = "ultra-secret"

TAG_RULES: Dict[str,str] = {
    "[general]": CATEGORY_GENERAL,
    "[confidential]": CATEGORY_CONF,
    "[secret]": CATEGORY_SECRET,
    "[ultra]": CATEGORY_ULTRA,
    "[ultra-secret]": CATEGORY_ULTRA,
}

PATTERNS = [
    (CATEGORY_ULTRA, re.compile(r"(seed phrase|private key|mnemonic|wallet\s*seed|ssh[-_ ]?key|api[_-]?secret)", re.I)),
    (CATEGORY_SECRET, re.compile(r"(password|passcode|otp|2fa|token|secret|client[_-]?secret)", re.I)),
    (CATEGORY_CONF,   re.compile(r"(email|address|phone|iban|card|credit\s*card|ssn|passport|id number|dob|date of birth)", re.I)),
]

def classify(text: str) -> Tuple[str, List[str]]:
    t = text.strip()
    for tag, cat in TAG_RULES.items():
        if tag in t.lower():
            return cat, [f"explicit-tag:{tag}"]
    hits: List[str] = []
    for cat, rx in PATTERNS:
        if rx.search(t):
            hits.append(cat)
    if CATEGORY_ULTRA in hits:
        return CATEGORY_ULTRA, ["pattern:ultra"]
    if CATEGORY_SECRET in hits:
        return CATEGORY_SECRET, ["pattern:secret"]
    if CATEGORY_CONF in hits:
        return CATEGORY_CONF, ["pattern:confidential"]
    return CATEGORY_GENERAL, ["pattern:default"]

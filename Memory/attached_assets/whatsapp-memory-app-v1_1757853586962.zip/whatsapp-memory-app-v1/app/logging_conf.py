import logging, sys, json, time
class JsonFormatter(logging.Formatter):
    def format(self, record):
        base = {"level": record.levelname, "time": int(time.time()*1000),
                "logger": record.name, "msg": record.getMessage()}
        if record.exc_info:
            base["exc_info"] = self.formatException(record.exc_info)
        return json.dumps(base)
def configure_logging(level=logging.INFO):
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter())
    logging.basicConfig(level=level, handlers=[handler])

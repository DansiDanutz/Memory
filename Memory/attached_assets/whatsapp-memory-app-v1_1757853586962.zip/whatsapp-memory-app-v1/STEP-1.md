# STEP 1 — WhatsApp Cloud API + Text → Markdown Storage

**Goal:** Set up WhatsApp (mobile phone number) with Cloud API, receive messages, and store **text** in per‑contact Markdown files divided into: `general`, `chronological`, `confidential`, `secret`, and `ultra-secret`. Reply to the user in WhatsApp.

---

## 1) WhatsApp setup (phone + Cloud API)

- Create a WhatsApp Business Account **(WABA)** in Meta for Developers.  
- Connect your business phone number to Cloud API.  
- Configure **Webhook** with your app’s public HTTPS URL and a `Verify token`. During verification, Meta sends `hub.mode`, `hub.verify_token`, and `hub.challenge`—your server must echo the challenge. See Meta’s webhook setup and echo‑bot quickstart.  
  - Docs: Webhook setup and echo bot.  
  - Docs: Webhook verification (hub.challenge).  
  - Docs: Sending messages via `/PHONE_NUMBER_ID/messages`.

> If you want to keep using the **same number on the mobile app**, Meta’s **Embedded Signup** supports **onboarding WhatsApp Business app users** (aka *Coexistence*) so a business phone can be used in the app and Cloud API (availability varies).

---

## 2) Environment variables (Replit → Secrets)

- `META_ACCESS_TOKEN` – Meta permanent access token  
- `WA_PHONE_NUMBER_ID` – Cloud API Phone Number ID  
- `META_VERIFY_TOKEN` – your verification string (must match Meta’s field)  
- `APP_PUBLIC_URL` – your public URL (Replit provides)  
- `DATA_DIR` – defaults to `./data`

---

## 3) Run locally (or in Replit)

```bash
pip install -r requirements.txt
bash scripts/dev_run.sh
# App listens on: / (health), /healthz, and the WhatsApp webhook /webhook/whatsapp
```

---

## 4) Data model (Markdown store)

For any incoming text from **+<E164>**, we create:

```
data/contacts/<E164>/memories/
  general.md
  chronological.md
  confidential.md
  secret.md
  ultra-secret.md
data/contacts/<E164>/meta.yaml
```

Each `.md` file has YAML front‑matter and entries like:

```markdown
## 2025-09-14T12:05:00Z — Incoming

- Message:
    Book hotel in Rome Oct 21–27.
- Classification: general
- Reasons: pattern:default
- Meta:
    wa_msg_id: WAB-...123
    name: Alice
```

**Classification rules (tunable):** explicit tags like `[secret]`, `[ultra]` override; otherwise heuristics detect PII (→ confidential), credentials (→ secret), crypto seed phrases (→ ultra-secret). See `app/memory/classifier.py`.

---

## 5) Verify the webhook in Meta and test

- **Callback URL**: `https://<your-app>/webhook/whatsapp`  
- **Verify Token**: same as `META_VERIFY_TOKEN`

Send a WhatsApp message from your phone to the business number. You should receive an ACK like:

```
Saved to confidential. You can 'search: <query>' or send a voice note.
```

---

## 6) Files added/modified in this step

- `app/config.py`, `app/logging_conf.py`  
- `app/memory/*` (classifier, storage)  
- `app/whatsapp.py` (webhook + send message)  
- `app/main.py` (app wiring)  
- `scripts/dev_run.sh`, `deploy/Dockerfile`, `requirements.txt`


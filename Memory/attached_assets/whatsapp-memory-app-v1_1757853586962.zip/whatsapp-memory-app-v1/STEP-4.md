# STEP 4 — Voice Q&A (Audio in ➜ Search ➜ Audio + Text out)

**Goal:** When a user sends a **voice note** in WhatsApp, transcribe it (STT), search their Markdown, and **reply with both text and synthesized voice** (TTS). If the voice says `verify: ...` or “my passphrase is …”, we verify and unlock secret tiers.

---

## 1) WhatsApp media flow

- Receive webhook payload with `type: "audio"` and `audio.id`.
- `GET /{media_id}` to fetch a CDN URL, then download the binary with Bearer auth.
- Convert **OGG/Opus** ➜ **WAV 16k mono** using `ffmpeg`.
- Transcribe via Azure Speech SDK. If the text starts with `verify:` or “my passphrase is …”, run verification and unlock secret tiers for 10 minutes.
- Otherwise treat transcript as a **search query** and reply with:
  - **Text**: top matches (category + timestamp)
  - **Voice**: synthesize summary to MP3, upload via `/PHONE_NUMBER_ID/media`, then send an audio message referencing that media.

---

## 2) Configuration

Add to your Secrets if not already set:

- `AZURE_SPEECH_KEY`
- `AZURE_SPEECH_REGION`

Ensure `VOICE_ENABLED=true` (default).

---

## 3) Notes

- If Azure Speech isn’t configured, the bot will respond that it cannot process voice yet.
- We keep the answers concise and include a list of the matched entries. Sensitive categories remain **locked** until verification succeeds.


# STEP 3 — Voice Passphrase Enrollment & Security Gating

**Goal:** Let the user **enroll a passphrase** and then require it to unlock **secret** and **ultra‑secret** categories for 10 minutes (per‑phone session).

---

## 1) Chat UX (no extra UI needed)

- **Enroll:** `enroll: <your secret phrase>`  
  → We hash and store in `meta.yaml` for that contact.
- **Verify:** `verify: <your secret phrase>` (or by voice in Step 4)  
  → If correct, we unlock **secret/ultra-secret** categories for **10 minutes**.

Default access without verification: `general`, `chronological`, `confidential`.

---

## 2) Implementation

- `app/voice/guard.py` — SHA‑256 hash of the passphrase stored per contact in `meta.yaml`.  
- `app/security/session.py` — in‑memory 10‑minute verification cache (`mark_verified`, `is_verified`).  
- `app/whatsapp.py` — chat commands: `enroll:`, `verify:`; computes allowed categories dynamically.  
- `app/main.py` — optional REST endpoints `/voice/enroll-passphrase`, `/voice/verify` for operator tests.

> For production scale or multiple instances, replace the in‑process session cache with **Redis** and use short TTLs.

---

## 3) Optional: biometric voice verification

You can later add **Azure Speaker Recognition**. Start with the Speech SDK docs and responsible‑use guidance before enabling biometric checks.

